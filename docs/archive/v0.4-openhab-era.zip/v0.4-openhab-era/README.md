# Archive: v0.4 openHAB Era

This directory contains documentation and code from the Gray Logic Stack v0.4 era,
when the architecture was based on openHAB + Node-RED + Docker Compose.

## Why Archived

In January 2026, the project pivoted to a custom-built "Gray Logic Core" approach:
- **Before**: openHAB as automation brain, Node-RED for glue logic, third-party UIs
- **After**: Custom Go-based core, native protocol bridges, custom UIs

## Contents

### Documentation
- `gray-logic-stack.md` - Full technical spec (v0.4)
- `architecture.md` - Network topology, VPN design, Desktop Utility API
- `business-case.md` - Commercial justification (still relevant for concepts)
- `sales-spec.md` - Canonical sales specification
- `appliance-architecture.md` - Backup strategy and deployment model
- `getting-started.md` - Lab setup guide for openHAB stack
- `modules/` - Per-module detail documents

### Code
- `stack/` - Docker Compose configuration for openHAB/Node-RED/Traefik
- `openhab/` - openHAB configuration files
- `node-red/` and `nodered/` - Node-RED flows
- `scripts/` - Backup/restore scripts

## What Carries Forward

The core **principles** from this era remain valid:
- Offline-first operation (99%+ without internet)
- Physical controls always work
- Life safety systems independent
- Open standards at field layer (KNX, DALI, Modbus)
- No vendor lock-in
- Predictive Health Monitoring concept
- Support tier model

The **implementation** is being rebuilt from scratch.

## Reference

These documents may be useful for:
- Understanding the evolution of the project
- Extracting specific technical decisions
- Business case concepts and pricing models
- PHM logic examples
