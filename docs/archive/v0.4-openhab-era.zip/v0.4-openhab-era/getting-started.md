# Getting Started - Gray Logic Stack Lab Setup

This guide walks you through setting up a local Gray Logic Stack development/lab environment.

## Prerequisites

- **Linux host** (Debian/Ubuntu recommended) or Linux VM
- **Docker** 24.0+ with Docker Compose v2
- **Git** for cloning the repository
- **4GB+ RAM** available for containers
- **10GB+ disk space** for images and data

### Install Docker (if needed)

```bash
# Debian/Ubuntu
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# Log out and back in for group changes to take effect
```

## Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/gray-logic-stack.git
cd gray-logic-stack
```

### 2. Configure Environment

```bash
cd code/stack

# Copy example environment file
cp .env.example .env

# Edit with your preferred settings
nano .env  # or vim, etc.
```

**Important**: Change these values in `.env`:
- `INFLUX_PASSWORD` - InfluxDB admin password
- `INFLUX_TOKEN` - InfluxDB API token (min 32 characters)
- `GRAFANA_PASSWORD` - Grafana admin password
- `NODERED_CREDENTIAL_SECRET` - Node-RED encryption key

### 3. Start the Stack

```bash
docker compose up -d
```

First run will pull images (~2-3GB total). This may take several minutes.

### 4. Verify Services

```bash
docker compose ps
```

All services should show "Up" or "healthy":

```
NAME                    STATUS              PORTS
graylogic-grafana       Up (healthy)        3000/tcp
graylogic-influxdb      Up (healthy)        8086/tcp
graylogic-mosquitto     Up (healthy)        0.0.0.0:1883->1883/tcp
graylogic-nodered       Up (healthy)        1880/tcp
graylogic-openhab       Up (healthy)        8080/tcp
graylogic-traefik       Up (healthy)        0.0.0.0:80->80/tcp, 0.0.0.0:443->443/tcp
```

### 5. Access Services

| Service | URL | Default Credentials |
|---------|-----|---------------------|
| openHAB | http://localhost | First-run wizard creates admin |
| Node-RED | http://localhost/nodered | No auth by default |
| Grafana | http://localhost/grafana | admin / (your GRAFANA_PASSWORD) |
| Traefik Dashboard | http://localhost:8080 | No auth (dev only) |
| InfluxDB | http://localhost/influxdb | admin / (your INFLUX_PASSWORD) |

## First-Time Configuration

### openHAB Setup

1. Access http://localhost
2. Complete the first-run wizard:
   - Create admin user
   - Choose "Standard" setup
   - Select your region/language
3. Install required add-ons:
   - **MQTT Binding** (for Node-RED/device communication)
   - **InfluxDB Persistence** (for metrics storage)
   - **Map Transformation** (for item state display)

#### Configure MQTT Binding

1. Go to **Settings > Things > Add Thing (+)**
2. Choose **MQTT Binding > MQTT Broker**
3. Configure:
   - Broker Hostname: `mosquitto`
   - Port: `1883`
   - Client ID: `openhab`
4. Save and verify connection shows "Online"

#### Configure InfluxDB Persistence

1. Go to **Settings > Add-ons > Other Add-ons**
2. Install **InfluxDB Persistence**
3. Go to **Settings > Persistence**
4. Configure InfluxDB:
   - URL: `http://influxdb:8086`
   - Token: (your INFLUX_TOKEN from .env)
   - Organization: `graylogic`
   - Bucket: `openhab`

#### Load Demo Items

Copy the demo configuration to the openHAB volume:

```bash
# From the repository root
docker cp code/openhab/conf/items/demo.items graylogic-openhab:/openhab/conf/items/
docker cp code/openhab/conf/rules/modes.rules graylogic-openhab:/openhab/conf/rules/
docker cp code/openhab/conf/transform/housemode.map graylogic-openhab:/openhab/conf/transform/
docker cp code/openhab/conf/transform/phmstatus.map graylogic-openhab:/openhab/conf/transform/
docker cp code/openhab/conf/persistence/influxdb.persist graylogic-openhab:/openhab/conf/persistence/

# Restart openHAB to load new config
docker compose restart openhab
```

### Node-RED Setup

1. Access http://localhost/nodered
2. Import the PHM demo flow:
   - Click the hamburger menu (☰) > **Import**
   - Select "Clipboard"
   - Paste contents of `code/nodered/flows/phm-pool-pump.json`
   - Click **Import**
3. Configure MQTT broker:
   - Double-click any MQTT node
   - Click the pencil icon next to "Server"
   - Verify: Server = `mosquitto`, Port = `1883`
   - Click **Update** then **Deploy**

### Grafana Setup

1. Access http://localhost/grafana
2. Log in with admin credentials
3. Verify InfluxDB datasource:
   - Go to **Connections > Data sources**
   - Click "InfluxDB"
   - Click **Test** - should show "Data source is working"
4. The "Gray Logic - Site Overview" dashboard should be available under **Dashboards > Browse > Gray Logic**

## Verifying the Stack

### Test MQTT Communication

```bash
# In one terminal, subscribe to all topics
docker exec -it graylogic-mosquitto mosquitto_sub -t '#' -v

# In another terminal, publish a test message
docker exec -it graylogic-mosquitto mosquitto_pub -t 'test/hello' -m 'world'
```

### Test PHM Flow

1. Open Node-RED (http://localhost/nodered)
2. The PHM flow should be running and simulating pump current
3. Check the debug panel - you should see PHM analysis messages
4. In openHAB, check the PoolPump_* items are receiving values

### Test Persistence

1. Wait 5 minutes for data to accumulate
2. Open Grafana > Gray Logic - Site Overview dashboard
3. You should see data appearing in the charts

## Common Operations

### View Logs

```bash
# All services
docker compose logs -f

# Specific service
docker compose logs -f openhab
docker compose logs -f nodered
```

### Restart a Service

```bash
docker compose restart openhab
```

### Stop the Stack

```bash
docker compose down
```

### Stop and Remove Data

```bash
# WARNING: This deletes all data!
docker compose down -v
```

### Backup

```bash
cd code/scripts
./backup.sh
```

### Restore

```bash
cd code/scripts
./restore.sh /var/backups/graylogic/your_backup.tar.gz
```

## Offline Resilience Test

The Gray Logic Stack is designed to work offline. Test this:

1. Ensure the stack is running and stable
2. Disconnect the host from the internet (or block outbound traffic)
3. Verify:
   - openHAB UI is still accessible
   - Mode changes work (click Mode_SetAway, etc.)
   - PHM flow continues running in Node-RED
   - Grafana dashboards show local data

Remote features (if configured) will pause, but core functionality continues.

## Next Steps

- **Add real devices**: Configure KNX, Modbus, or MQTT devices in openHAB
- **Customize PHM**: Modify the pool pump flow for your actual equipment
- **Build dashboards**: Create Grafana dashboards for your use case
- **Enable remote access**: Configure WireGuard VPN for secure remote access

## Troubleshooting

### Services won't start

```bash
# Check for port conflicts
sudo lsof -i :80
sudo lsof -i :1883

# Check Docker logs
docker compose logs traefik
```

### openHAB shows "OFFLINE"

- Wait 2-3 minutes after first start (Java startup is slow)
- Check logs: `docker compose logs openhab`

### Node-RED can't connect to MQTT

- Verify Mosquitto is running: `docker compose ps mosquitto`
- Check MQTT broker config uses hostname `mosquitto`, not `localhost`

### Grafana shows "No data"

- Wait for persistence to write data (5-15 minutes)
- Verify InfluxDB datasource test passes
- Check InfluxDB has data: access http://localhost/influxdb

### Permission errors on Linux

```bash
# Fix Docker socket permissions
sudo chmod 666 /var/run/docker.sock

# Or add user to docker group (requires re-login)
sudo usermod -aG docker $USER
```

## Architecture Reference

```
┌─────────────────────────────────────────────────────────────┐
│                     Web Browser                              │
└─────────────────────────────┬───────────────────────────────┘
                              │ HTTP/HTTPS
┌─────────────────────────────▼───────────────────────────────┐
│                        Traefik                               │
│                    (Reverse Proxy)                           │
│              localhost:80, localhost:443                     │
└───────┬──────────┬──────────┬──────────┬───────────────────┘
        │          │          │          │
   ┌────▼────┐ ┌───▼────┐ ┌───▼────┐ ┌───▼─────┐
   │ openHAB │ │Node-RED│ │Grafana │ │InfluxDB │
   │  :8080  │ │ :1880  │ │ :3000  │ │  :8086  │
   └────┬────┘ └───┬────┘ └───┬────┘ └────┬────┘
        │          │          │           │
        └──────────┴────┬─────┴───────────┘
                        │
                 ┌──────▼──────┐
                 │  Mosquitto  │
                 │ (MQTT :1883)│
                 └─────────────┘
```

See `docs/architecture.md` for full network design and security model.
