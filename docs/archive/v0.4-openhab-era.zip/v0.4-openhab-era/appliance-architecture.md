# Gray Logic Stack - Appliance Architecture & Backup Strategy

## Overview

Define the deployment model, OS hardening, and backup strategy for Gray Logic NOC devices to ensure resilience, factory-reset capability, and disaster recovery.

## Design Decisions (Confirmed)

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Base OS | Minimal Debian 13 (Trixie) + Docker | Current stable LTS, supported until 2030 (LTS) / 2035 (ELTS) |
| Customer Access | Full SSH with warnings | They can access but "warranty void if you touch this" |
| Golden Backup Locations | USB + Your Cloud + Customer Cloud (optional) | Maximum redundancy |

---

## Architecture: Two-Tier Backup Model

### Tier 1: Golden Backup (Commissioning Snapshot)

**What it is:** A complete snapshot of the system state after commissioning, representing the "factory configured" state.

**When created:**
- Once, at end of commissioning
- Updated only during formal re-commissioning or major upgrades
- Signed off by technician

**What it contains:**
- Docker Compose configuration
- Environment file (.env) - credentials, site config
- openHAB config (items, rules, things, transforms, sitemaps)
- Node-RED flows and settings
- Grafana provisioning and custom dashboards
- Traefik configuration
- Mosquitto configuration
- Any custom scripts

**What it does NOT contain:**
- InfluxDB data (ephemeral, 30-day rolling)
- Log files
- Temporary/cache files
- Docker images (pulled fresh on restore)

**Where it lives:**

| Location | Purpose | Encrypted |
|----------|---------|-----------|
| USB drive (customer handover pack) | Disaster recovery, physical backup | Yes (GPG) |
| Internal partition (/opt/graylogic/golden) | Local factory reset source | Optional |
| Backblaze B2 (your account) | Offsite, you control it | Yes |
| Customer S3/B2 (optional) | Customer's own DR compliance | Yes |

**Restore triggers:**
- "Factory Reset" button/command
- Disaster recovery from USB
- Remote restore by technician

---

### Tier 2: Operational Backup (Runtime Snapshots)

**What it is:** Periodic snapshots of running config including customer preference changes.

**When created:**
- Before any remote update/change (automatic)
- Weekly automated
- On-demand by technician
- After significant customer changes (if detectable)

**What it captures (beyond Golden):**

| Category | Examples |
|----------|----------|
| **Timers & Schedules** | Wake-up times, heating schedules, lighting timers |
| **Scene Customizations** | Custom scene levels, favorite scenes, room groupings |
| **Event Actions** | "When doorbell rings, turn on hall light" |
| **Mode Preferences** | Away mode behavior tweaks, night mode timing |
| **Dashboard Layouts** | Grafana dashboard customizations, openHAB sitemap tweaks |
| **Threshold Adjustments** | PHM sensitivity, alert thresholds |
| **Consumer Overlay State** | Which overlay devices are enabled, their automations |

**What it does NOT capture:**
- InfluxDB data (ephemeral)
- Log files
- Temporary state

**Where it lives:**
- Local: `/var/backups/graylogic/operational/`
- 30-day retention, rolling (configurable)
- VPS: Pushed to your server (Premium tier or configured)

**Versioning:**
```
/var/backups/graylogic/operational/
├── 2025-01-12_daily.tar.gz
├── 2025-01-11_daily.tar.gz
├── 2025-01-10_pre-update.tar.gz  (before technician change)
├── 2025-01-05_daily.tar.gz
└── ...
```

**Purpose:**
- Rollback after failed update
- "Undo" for technician mistakes
- Preserve customer preferences across re-commissioning
- NOT for factory reset (that uses Golden)

**Customer Preference Preservation:**
When re-commissioning or major update:
1. Take operational backup first
2. Apply update/changes
3. Offer to merge customer preferences back in (where compatible)

---

## OS Hardening (Minimal Debian)

### Base Image Specification

```
Debian 13 (Trixie) Minimal
├── No desktop environment
├── No unnecessary services (cups, avahi-daemon, etc.)
├── SSH server (key-only auth)
├── Docker CE + Docker Compose v2
├── iptables firewall (iptables-persistent)
├── Fail2ban (optional)
├── NTP client (systemd-timesyncd)
└── Gray Logic bootstrap script
```

### Firewall Rules (iptables)

```bash
#!/bin/bash
# /opt/graylogic/scripts/firewall.sh
# Gray Logic NOC iptables rules

# Flush existing rules
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X

# Default policies
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# Allow loopback
iptables -A INPUT -i lo -j ACCEPT

# Allow established connections
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Allow SSH (consider restricting to management VLAN)
iptables -A INPUT -p tcp --dport 22 -j ACCEPT

# Allow HTTP/HTTPS (Traefik)
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT

# Allow MQTT from local networks only
iptables -A INPUT -p tcp --dport 1883 -s 192.168.0.0/16 -j ACCEPT
iptables -A INPUT -p tcp --dport 1883 -s 10.0.0.0/8 -j ACCEPT
iptables -A INPUT -p tcp --dport 1883 -s 172.16.0.0/12 -j ACCEPT

# Allow Traefik dashboard from local only (disable in production)
iptables -A INPUT -p tcp --dport 8080 -s 192.168.0.0/16 -j ACCEPT
iptables -A INPUT -p tcp --dport 8080 -s 10.0.0.0/8 -j ACCEPT

# Allow WireGuard (if configured)
iptables -A INPUT -p udp --dport 51820 -j ACCEPT

# Allow ICMP (ping)
iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT

# Log dropped packets (optional, can be noisy)
# iptables -A INPUT -j LOG --log-prefix "DROPPED: " --log-level 4

# Save rules (Debian)
iptables-save > /etc/iptables/rules.v4
```

```bash
# Make persistent on boot
apt install iptables-persistent
# Rules auto-load from /etc/iptables/rules.v4
```

### User Setup

```
root          - Disabled direct login
graylogic     - Service account, runs Docker, no sudo by default
gl-admin      - Technician account, sudo access, SSH key only
```

### SSH Hardening

```
# /etc/ssh/sshd_config.d/graylogic.conf
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
AllowUsers gl-admin
MaxAuthTries 3
```

### "Warranty Void" Warning

On SSH login (via /etc/motd):

```
╔══════════════════════════════════════════════════════════════════╗
║                    GRAY LOGIC STACK NOC                          ║
╠══════════════════════════════════════════════════════════════════╣
║  This system is configured and maintained by Gray Logic.         ║
║                                                                   ║
║  WARNING: Manual changes to this system may void your support    ║
║  agreement. If you need changes, contact your Gray Logic         ║
║  technician.                                                      ║
║                                                                   ║
║  Support: support@graylogic.uk                                   ║
║  Factory Reset: sudo graylogic-reset                             ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## Factory Reset Mechanism

### User-Facing Command

```bash
sudo graylogic-reset
```

**What it does:**
1. Confirms with user (type YES to proceed)
2. Stops all Docker services
3. Removes current config volumes
4. Restores from golden backup (local partition first, USB fallback)
5. Recreates volumes from backup
6. Starts services
7. Logs reset event

### Implementation: `/usr/local/bin/graylogic-reset`

```bash
#!/usr/bin/env bash
# Gray Logic Factory Reset
# Restores system to commissioning state

GOLDEN_DIR="/opt/graylogic/golden"
GOLDEN_USB="/mnt/graylogic-usb"  # Auto-mounted if present

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║              GRAY LOGIC FACTORY RESET                     ║"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║  This will restore the system to its commissioning state. ║"
echo "║  All changes since installation will be LOST.             ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""
read -p "Type YES to confirm factory reset: " confirm

if [[ "$confirm" != "YES" ]]; then
    echo "Reset cancelled."
    exit 0
fi

# Find golden backup source
if [[ -f "${GOLDEN_DIR}/golden.tar.gz" ]]; then
    BACKUP_SOURCE="${GOLDEN_DIR}/golden.tar.gz"
elif [[ -f "${GOLDEN_USB}/golden.tar.gz" ]]; then
    BACKUP_SOURCE="${GOLDEN_USB}/golden.tar.gz"
else
    echo "ERROR: No golden backup found!"
    exit 1
fi

echo "Restoring from: $BACKUP_SOURCE"
# ... (calls restore.sh with --factory flag)
```

---

## Commissioning Workflow

### Step-by-Step

1. **Technician deploys OS** (from Gray Logic base image or fresh Debian + bootstrap)
2. **Technician configures stack** (docker-compose up, configure openHAB, Node-RED, etc.)
3. **Technician runs commissioning tests** (verify all systems, PHM flows, dashboards)
4. **Customer signs off** (system works as expected)
5. **Technician creates golden backup:**
   ```bash
   sudo graylogic-commission --create-golden
   ```
   This:
   - Stops services gracefully
   - Creates encrypted backup archive
   - Copies to local partition
   - Copies to USB (inserted by technician)
   - Uploads to Backblaze B2
   - Optionally uploads to customer's S3/B2
   - Generates commissioning report
   - Restarts services

6. **USB goes into customer's handover pack** (sealed envelope with other docs)
7. **System is now "set and forget"**

---

## Remote Backup Architecture

### Design: VPS Relay Model

Customer sites do NOT have direct Backblaze access. Instead:

```
┌─────────────────┐      WireGuard VPN      ┌─────────────────┐
│  Customer NOC   │ ──────────────────────► │   Your VPS      │
│                 │   encrypted backup      │   (relay)       │
│  golden.tar.gz  │                         │                 │
│  + GPG encrypt  │                         │  Receives &     │
└─────────────────┘                         │  stores in B2   │
                                            └────────┬────────┘
                                                     │
                                                     ▼
                                            ┌─────────────────┐
                                            │  Backblaze B2   │
                                            │  (your account) │
                                            │                 │
                                            │  /site-001/     │
                                            │  /site-002/     │
                                            │  /site-003/     │
                                            └─────────────────┘
```

### Why This Model

| Concern | Solution |
|---------|----------|
| Per-customer B2 credentials | Not needed - VPS handles B2 |
| Credential management | Only VPS has B2 creds, customers have VPN only |
| Cost | Single B2 account, pay for actual storage |
| Security | Data encrypted BEFORE leaving customer site |
| Control | You own the storage, can manage retention |

### Encryption Model

```
Customer Site:
1. Create golden backup (tar.gz)
2. Encrypt with GPG using Gray Logic public key
3. Push to VPS via WireGuard: rsync/scp to /incoming/site-id/

VPS:
1. Receives encrypted file (cannot decrypt - no private key on VPS)
2. Validates checksum
3. Uploads to Backblaze B2
4. Cleans up /incoming/

Gray Logic Office:
- Holds GPG private keys (air-gapped or hardware key)
- Can decrypt if needed for disaster recovery
```

### Upload Flow (Customer Side)

```bash
# Part of graylogic-commission --create-golden

# 1. Create and encrypt
tar czf golden.tar.gz [config files]
gpg --encrypt --recipient graylogic-master golden.tar.gz
sha256sum golden.tar.gz.gpg > golden.tar.gz.gpg.sha256

# 2. Push to VPS (via WireGuard - already connected)
rsync -avz --progress \
    golden.tar.gz.gpg \
    golden.tar.gz.gpg.sha256 \
    graylogic-vps:/incoming/${SITE_ID}/

# 3. VPS handles B2 upload asynchronously
```

### VPS Receiver Service

Simple systemd service or cron job on VPS:

```bash
#!/bin/bash
# /opt/graylogic/scripts/process-incoming-backups.sh

INCOMING_DIR="/incoming"
B2_BUCKET="graylogic-customer-backups"

for site_dir in "$INCOMING_DIR"/*/; do
    site_id=$(basename "$site_dir")

    for backup in "$site_dir"/*.gpg; do
        [ -f "$backup" ] || continue

        # Validate checksum
        if sha256sum -c "${backup}.sha256"; then
            # Upload to B2
            b2 upload-file "$B2_BUCKET" "$backup" \
                "${site_id}/$(basename $backup)"

            # Cleanup
            rm -f "$backup" "${backup}.sha256"

            logger "Backup uploaded: $site_id/$(basename $backup)"
        else
            logger -p user.error "Checksum failed: $backup"
        fi
    done
done
```

### Backblaze B2 Structure

```
b2://graylogic-customer-backups/
├── site-001-smithhouse/
│   ├── golden-2025-01-15.tar.gz.gpg
│   └── golden-2025-06-20.tar.gz.gpg  (re-commission)
├── site-002-poolleisure/
│   └── golden-2025-03-01.tar.gz.gpg
└── ...
```

### VPS-Side Isolation (Critical Security)

Each customer's upload path is **isolated and write-only**. Configured on VPS, not trusting customer devices.

**Directory Structure:**
```
/srv/graylogic/incoming/
├── site-001/    # Only site-001 can write here
├── site-002/    # Only site-002 can write here
└── site-003/    # etc.
```

**Per-Site User Accounts:**
```bash
# Create dedicated user per site (no shell, no home)
useradd -r -s /usr/sbin/nologin -d /srv/graylogic/incoming/site-001 site-001-upload

# Create directory with strict permissions
mkdir -p /srv/graylogic/incoming/site-001
chown site-001-upload:graylogic /srv/graylogic/incoming/site-001
chmod 730 /srv/graylogic/incoming/site-001
# 730 = owner rwx, group wx, others none
# Group write allows the backup processor service to read
```

**SSH Configuration (rsync over SSH):**
```bash
# /etc/ssh/sshd_config.d/graylogic-uploads.conf

# Restrict site users to their own directory, rsync only
Match User site-*-upload
    ChrootDirectory /srv/graylogic/incoming/%u
    ForceCommand internal-sftp -u 0022
    AllowTcpForwarding no
    X11Forwarding no
    PermitTunnel no
    AllowAgentForwarding no
```

Wait - chroot with the username won't work cleanly. Better approach:

**Alternative: Dedicated SSH Keys with forced commands:**
```bash
# ~/.ssh/authorized_keys for site-001-upload user
command="rsync --server -vre.iLsfxCIvu . /srv/graylogic/incoming/site-001/",restrict ssh-ed25519 AAAA... site-001-noc

# This restricts the key to ONLY receiving rsync to that specific directory
```

**Why This Matters:**
- Customer site-001 cannot see/read site-002's data
- Customer cannot read their own uploaded data back (write-only)
- Customer cannot execute arbitrary commands
- Even if customer NOC is compromised, attacker is jailed to empty write-only directory

**Backup Processor Runs as Separate User:**
```bash
# graylogic-backup-processor user
# - Can read from all /srv/graylogic/incoming/*/
# - Can upload to B2
# - Cleans up after successful upload
```

### Credentials Summary

| Location | Has Access To |
|----------|---------------|
| Customer NOC | WireGuard VPN to your VPS (only) |
| Customer NOC | GPG public key (encrypt only) |
| Customer NOC | SSH key for site-specific upload user (write-only to own dir) |
| Your VPS | Per-site upload users (isolated, write-only) |
| Your VPS | B2 application key (upload only) |
| Your VPS | WireGuard server |
| Gray Logic Office | GPG private key (decrypt) |
| Gray Logic Office | B2 master credentials |
| Gray Logic Office | SSH access to VPS (full admin) |

### Cost Estimate (Backblaze B2)

- Storage: $0.006/GB/month
- Download: $0.01/GB (only when restoring)
- Transactions: Essentially free at this scale

Example: 50 sites × 500MB golden backup = 25GB = ~$0.15/month storage

---

## Files to Create/Modify

| File | Action | Description |
|------|--------|-------------|
| `code/scripts/graylogic-commission.sh` | Create | Commissioning script with golden backup |
| `code/scripts/graylogic-reset.sh` | Create | Factory reset script |
| `code/scripts/backup.sh` | Modify | Add --golden flag, clarify as "operational" backup |
| `code/os/base-image.md` | Create | Debian base image specification |
| `code/os/bootstrap.sh` | Create | Bootstrap script for fresh Debian install |
| `code/os/sshd-config` | Create | SSH hardening config |
| `code/os/firewall.sh` | Create | iptables firewall setup script |
| `code/os/motd` | Create | Login warning banner |
| `code/vps/setup-site-user.sh` | Create | Script to provision isolated upload user per site |
| `code/vps/backup-processor.sh` | Create | Service to process incoming and upload to B2 |
| `docs/architecture.md` | Update | Add deployment model section |
| `docs/commissioning-guide.md` | Create | Step-by-step commissioning docs |

---

## Data Flow Summary

```
COMMISSIONING
─────────────
Technician configures system
         │
         ▼
    ┌─────────┐
    │ Golden  │───┬──► USB (customer handover pack)
    │ Backup  │   │
    └─────────┘   ├──► Local partition (/opt/graylogic/golden/)
                  │
                  ├──► Backblaze B2 (encrypted)
                  │
                  └──► Customer S3/B2 (optional, encrypted)


RUNTIME
───────
System runs normally
         │
         ├──► Operational backups (local, 30-day rolling)
         │
         └──► InfluxDB data (30-day, NOT backed up offsite)


FACTORY RESET
─────────────
Customer/Technician triggers reset
         │
         ▼
    Restore from Golden Backup (local → USB fallback)
         │
         ▼
    System returns to commissioning state
```

---

## Verification Steps

1. **Commissioning creates valid golden backup**
   - Archive contains all expected files
   - Can be extracted and validated
   - Uploaded to all destinations

2. **Factory reset works**
   - Reset restores to commissioning state
   - Services start correctly after reset
   - No data from post-commissioning remains

3. **USB backup is usable**
   - Can boot from live USB and restore
   - Encryption/decryption works

4. **Backblaze backup is retrievable**
   - Can download and decrypt
   - Matches local golden backup
