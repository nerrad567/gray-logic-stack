# openHAB configuration

This directory will contain Gray Logic-specific openHAB configuration,
such as things, items, rules, and UI definitions.

Structure and usage:
- conf/ style layout to mirror an openHAB installation,
- Example configs and templates for Gray Logic deployments.
