#!/usr/bin/env bash
# =============================================================================
# Gray Logic Stack - Restore Script
# =============================================================================
# Restores a Gray Logic Stack from backup
#
# Usage:
#   ./restore.sh /path/to/backup.tar.gz
#
# This script will:
#   1. Stop all running services
#   2. Remove existing volumes (with confirmation)
#   3. Restore configuration files
#   4. Restore Docker volumes
#   5. Start services
#
# IMPORTANT: This is a destructive operation!
# Current data will be replaced with backup data.
# =============================================================================

set -euo pipefail

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STACK_DIR="${SCRIPT_DIR}/../stack"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# -----------------------------------------------------------------------------
# Functions
# -----------------------------------------------------------------------------
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${CYAN}[STEP]${NC} $1"
}

usage() {
    echo "Usage: $0 <backup_file.tar.gz>"
    echo ""
    echo "Restores Gray Logic Stack from a backup archive."
    echo ""
    echo "Options:"
    echo "  -f, --force    Skip confirmation prompts"
    echo "  -h, --help     Show this help message"
    exit 1
}

check_requirements() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed or not in PATH"
        exit 1
    fi

    if ! command -v tar &> /dev/null; then
        log_error "tar is not installed"
        exit 1
    fi
}

validate_backup() {
    local backup_file="$1"

    if [[ ! -f "$backup_file" ]]; then
        log_error "Backup file not found: $backup_file"
        exit 1
    fi

    if [[ ! "$backup_file" =~ \.tar\.gz$ ]]; then
        log_error "Backup file must be a .tar.gz archive"
        exit 1
    fi

    # Check if it's a valid archive
    if ! tar tzf "$backup_file" &>/dev/null; then
        log_error "Invalid or corrupted backup archive"
        exit 1
    fi

    log_info "Backup file validated: $backup_file"
}

show_backup_info() {
    local backup_file="$1"
    local temp_dir=$(mktemp -d)

    # Extract just the metadata file
    tar xzf "$backup_file" -C "$temp_dir" backup_metadata.json 2>/dev/null || true

    if [[ -f "${temp_dir}/backup_metadata.json" ]]; then
        echo ""
        log_info "Backup Information:"
        echo "----------------------------------------"
        cat "${temp_dir}/backup_metadata.json" | while read line; do
            echo "  $line"
        done
        echo "----------------------------------------"
        echo ""
    fi

    rm -rf "$temp_dir"
}

confirm_restore() {
    local force="$1"

    if [[ "$force" == "true" ]]; then
        return 0
    fi

    echo ""
    log_warn "WARNING: This will REPLACE all current data with backup data!"
    log_warn "Current openHAB config, Node-RED flows, and Grafana dashboards will be LOST."
    echo ""
    read -p "Are you sure you want to continue? (yes/no): " confirm

    if [[ "$confirm" != "yes" ]]; then
        log_info "Restore cancelled."
        exit 0
    fi
}

stop_services() {
    log_step "Stopping all services..."
    cd "$STACK_DIR"

    docker compose down 2>/dev/null || true

    # Wait for containers to fully stop
    sleep 5
}

remove_volumes() {
    log_step "Removing existing volumes..."

    local volumes=(
        "graylogic_openhab_conf"
        "graylogic_openhab_userdata"
        "graylogic_openhab_addons"
        "graylogic_nodered_data"
        "graylogic_grafana_data"
        "graylogic_mosquitto_data"
        "graylogic_mosquitto_log"
        "graylogic_influxdb_data"
        "graylogic_influxdb_config"
        "graylogic_traefik_certs"
    )

    for vol in "${volumes[@]}"; do
        if docker volume inspect "$vol" &>/dev/null; then
            log_info "  Removing volume: $vol"
            docker volume rm "$vol" 2>/dev/null || true
        fi
    done
}

restore_config_files() {
    local temp_dir="$1"

    log_step "Restoring configuration files..."

    # Restore docker-compose.yml
    if [[ -f "${temp_dir}/config/docker-compose.yml" ]]; then
        cp "${temp_dir}/config/docker-compose.yml" "${STACK_DIR}/"
        log_info "  Restored: docker-compose.yml"
    fi

    # Restore .env
    if [[ -f "${temp_dir}/config/.env" ]]; then
        cp "${temp_dir}/config/.env" "${STACK_DIR}/"
        log_info "  Restored: .env"
    fi

    # Restore Traefik config
    if [[ -d "${temp_dir}/config/traefik" ]]; then
        rm -rf "${STACK_DIR}/traefik"
        cp -r "${temp_dir}/config/traefik" "${STACK_DIR}/"
        log_info "  Restored: traefik/"
    fi

    # Restore Mosquitto config
    if [[ -d "${temp_dir}/config/mosquitto" ]]; then
        rm -rf "${STACK_DIR}/mosquitto"
        cp -r "${temp_dir}/config/mosquitto" "${STACK_DIR}/"
        log_info "  Restored: mosquitto/"
    fi

    # Restore Grafana config
    if [[ -d "${temp_dir}/config/grafana" ]]; then
        rm -rf "${STACK_DIR}/grafana"
        cp -r "${temp_dir}/config/grafana" "${STACK_DIR}/"
        log_info "  Restored: grafana/"
    fi
}

restore_volumes() {
    local temp_dir="$1"

    log_step "Restoring Docker volumes..."

    # Map of backup files to volume names
    declare -A volume_map=(
        ["openhab_conf.tar.gz"]="graylogic_openhab_conf"
        ["openhab_userdata.tar.gz"]="graylogic_openhab_userdata"
        ["nodered_data.tar.gz"]="graylogic_nodered_data"
        ["grafana_data.tar.gz"]="graylogic_grafana_data"
        ["mosquitto_data.tar.gz"]="graylogic_mosquitto_data"
    )

    for backup_name in "${!volume_map[@]}"; do
        local vol_name="${volume_map[$backup_name]}"
        local backup_path="${temp_dir}/${backup_name}"

        if [[ -f "$backup_path" ]]; then
            log_info "  Restoring volume: $vol_name"

            # Create the volume
            docker volume create "$vol_name" &>/dev/null

            # Restore data to volume
            docker run --rm \
                -v "${vol_name}:/target" \
                -v "${backup_path}:/backup.tar.gz:ro" \
                alpine sh -c "cd /target && tar xzf /backup.tar.gz"
        else
            log_warn "  Backup not found (skipping): $backup_name"
        fi
    done
}

start_services() {
    log_step "Starting services..."
    cd "$STACK_DIR"

    docker compose up -d

    log_info "Waiting for services to start..."
    sleep 30

    # Check service status
    docker compose ps
}

verify_restore() {
    log_step "Verifying restore..."

    local all_healthy=true

    # Check if key services are running
    cd "$STACK_DIR"

    for service in traefik openhab nodered mosquitto influxdb grafana; do
        if docker compose ps "$service" 2>/dev/null | grep -q "Up"; then
            log_info "  $service: Running"
        else
            log_warn "  $service: Not running (may still be starting)"
            all_healthy=false
        fi
    done

    if [[ "$all_healthy" == "true" ]]; then
        log_info "All services running!"
    else
        log_warn "Some services may still be starting. Check with: docker compose ps"
    fi
}

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
main() {
    local backup_file=""
    local force="false"

    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -f|--force)
                force="true"
                shift
                ;;
            -h|--help)
                usage
                ;;
            *)
                backup_file="$1"
                shift
                ;;
        esac
    done

    if [[ -z "$backup_file" ]]; then
        usage
    fi

    log_info "=========================================="
    log_info "Gray Logic Stack Restore"
    log_info "=========================================="
    log_info "Backup file: $backup_file"
    log_info ""

    check_requirements
    validate_backup "$backup_file"
    show_backup_info "$backup_file"
    confirm_restore "$force"

    # Create temp directory and extract backup
    local temp_dir=$(mktemp -d)
    log_info "Extracting backup to temporary directory..."
    tar xzf "$backup_file" -C "$temp_dir"

    # Perform restore
    stop_services
    remove_volumes
    restore_config_files "$temp_dir"
    restore_volumes "$temp_dir"
    start_services
    verify_restore

    # Cleanup
    rm -rf "$temp_dir"

    log_info ""
    log_info "=========================================="
    log_info "Restore completed!"
    log_info "=========================================="
    log_info ""
    log_info "Next steps:"
    log_info "  1. Access openHAB at http://localhost (or via Traefik)"
    log_info "  2. Verify items and rules are restored"
    log_info "  3. Check Node-RED flows at /nodered"
    log_info "  4. Verify Grafana dashboards at /grafana"
    log_info ""
    log_info "If using InfluxDB persistence, historical data will need to rebuild."
}

# Run main function
main "$@"
