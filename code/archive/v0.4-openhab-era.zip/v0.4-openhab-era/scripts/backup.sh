#!/usr/bin/env bash
# =============================================================================
# Gray Logic Stack - Backup Script
# =============================================================================
# Creates a backup of all Gray Logic Stack configuration and data
#
# Usage:
#   ./backup.sh                    # Backup to default location
#   ./backup.sh /path/to/backup    # Backup to specific directory
#   BACKUP_DIR=/mnt/usb ./backup.sh # Use environment variable
#
# Backed up:
#   - Docker Compose configuration
#   - openHAB config (items, rules, things, persistence, transforms)
#   - openHAB userdata (state, persistence data)
#   - Node-RED flows and settings
#   - Traefik configuration
#   - Mosquitto configuration
#   - Grafana configuration and dashboards
#
# NOT backed up (by design):
#   - InfluxDB data (large, can be recreated)
#   - Log files
#   - Temporary/cache files
# =============================================================================

set -euo pipefail

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STACK_DIR="${SCRIPT_DIR}/../stack"
BACKUP_DIR="${1:-${BACKUP_DIR:-/var/backups/graylogic}}"
SITE_NAME="${GL_SITE_NAME:-graylogic}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="${SITE_NAME}_backup_${TIMESTAMP}"
BACKUP_FILE="${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# -----------------------------------------------------------------------------
# Functions
# -----------------------------------------------------------------------------
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_requirements() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed or not in PATH"
        exit 1
    fi

    if ! command -v tar &> /dev/null; then
        log_error "tar is not installed"
        exit 1
    fi
}

create_backup_dir() {
    if [[ ! -d "$BACKUP_DIR" ]]; then
        log_info "Creating backup directory: $BACKUP_DIR"
        mkdir -p "$BACKUP_DIR"
    fi
}

stop_services() {
    log_info "Stopping services for consistent backup..."
    cd "$STACK_DIR"

    # Stop services that write to volumes
    docker compose stop openhab nodered grafana 2>/dev/null || true

    # Give services time to flush
    sleep 5
}

start_services() {
    log_info "Restarting services..."
    cd "$STACK_DIR"
    docker compose start openhab nodered grafana 2>/dev/null || true
}

backup_volumes() {
    log_info "Backing up Docker volumes..."

    local temp_dir=$(mktemp -d)
    local volumes_backed_up=0

    # List of volumes to backup
    declare -A volumes=(
        ["graylogic_openhab_conf"]="openhab_conf"
        ["graylogic_openhab_userdata"]="openhab_userdata"
        ["graylogic_nodered_data"]="nodered_data"
        ["graylogic_grafana_data"]="grafana_data"
        ["graylogic_mosquitto_data"]="mosquitto_data"
    )

    for vol_name in "${!volumes[@]}"; do
        local backup_name="${volumes[$vol_name]}"

        if docker volume inspect "$vol_name" &>/dev/null; then
            log_info "  Backing up volume: $vol_name"
            docker run --rm \
                -v "${vol_name}:/source:ro" \
                -v "${temp_dir}:/backup" \
                alpine tar czf "/backup/${backup_name}.tar.gz" -C /source .
            ((volumes_backed_up++))
        else
            log_warn "  Volume not found (skipping): $vol_name"
        fi
    done

    log_info "Backed up $volumes_backed_up volumes"

    # Return temp directory path
    echo "$temp_dir"
}

backup_config_files() {
    local temp_dir="$1"

    log_info "Backing up configuration files..."

    # Create config directory
    mkdir -p "${temp_dir}/config"

    # Backup docker-compose and env
    if [[ -f "${STACK_DIR}/docker-compose.yml" ]]; then
        cp "${STACK_DIR}/docker-compose.yml" "${temp_dir}/config/"
    fi

    if [[ -f "${STACK_DIR}/.env" ]]; then
        cp "${STACK_DIR}/.env" "${temp_dir}/config/"
    fi

    # Backup Traefik config
    if [[ -d "${STACK_DIR}/traefik" ]]; then
        cp -r "${STACK_DIR}/traefik" "${temp_dir}/config/"
    fi

    # Backup Mosquitto config
    if [[ -d "${STACK_DIR}/mosquitto" ]]; then
        cp -r "${STACK_DIR}/mosquitto" "${temp_dir}/config/"
    fi

    # Backup Grafana provisioning
    if [[ -d "${STACK_DIR}/grafana" ]]; then
        cp -r "${STACK_DIR}/grafana" "${temp_dir}/config/"
    fi
}

create_archive() {
    local temp_dir="$1"

    log_info "Creating backup archive: $BACKUP_FILE"

    # Create metadata file
    cat > "${temp_dir}/backup_metadata.json" << EOF
{
    "site_name": "${SITE_NAME}",
    "backup_date": "$(date -Iseconds)",
    "backup_type": "full",
    "stack_version": "0.5",
    "hostname": "$(hostname)",
    "docker_version": "$(docker --version | cut -d' ' -f3 | tr -d ',')"
}
EOF

    # Create the archive
    tar czf "$BACKUP_FILE" -C "$temp_dir" .

    # Cleanup temp directory
    rm -rf "$temp_dir"

    # Show backup info
    local backup_size=$(du -h "$BACKUP_FILE" | cut -f1)
    log_info "Backup complete: $BACKUP_FILE ($backup_size)"
}

cleanup_old_backups() {
    local retention_days="${BACKUP_RETENTION_DAYS:-30}"

    log_info "Cleaning up backups older than $retention_days days..."

    local deleted_count=$(find "$BACKUP_DIR" -name "${SITE_NAME}_backup_*.tar.gz" -mtime +$retention_days -delete -print | wc -l)

    if [[ $deleted_count -gt 0 ]]; then
        log_info "Deleted $deleted_count old backup(s)"
    fi
}

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
main() {
    log_info "=========================================="
    log_info "Gray Logic Stack Backup"
    log_info "=========================================="
    log_info "Site: $SITE_NAME"
    log_info "Backup directory: $BACKUP_DIR"
    log_info ""

    check_requirements
    create_backup_dir

    # Stop services for consistent backup
    stop_services

    # Perform backup
    local temp_dir
    temp_dir=$(backup_volumes)
    backup_config_files "$temp_dir"
    create_archive "$temp_dir"

    # Restart services
    start_services

    # Cleanup old backups
    cleanup_old_backups

    log_info ""
    log_info "=========================================="
    log_info "Backup completed successfully!"
    log_info "=========================================="
}

# Run main function
main "$@"
