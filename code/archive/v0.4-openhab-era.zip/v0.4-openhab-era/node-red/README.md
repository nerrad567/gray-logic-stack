# Node-RED flows

This directory will contain Node-RED flows and related assets
used by the Gray Logic stack for cross-system logic and integrations.

Typical contents:
- Exported flow JSON files
- Subflow definitions
- Notes on how flows map to Gray Logic modules.
